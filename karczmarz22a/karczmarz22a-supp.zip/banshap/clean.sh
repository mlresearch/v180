rm -rf tex
rm -rf .git*

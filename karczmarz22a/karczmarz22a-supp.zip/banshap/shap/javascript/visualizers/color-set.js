export default {
  colors: {
    RdBu: ["rgb(255, 13, 87)", "rgb(30, 136, 229)"],
    GnPR: ["rgb(24, 196, 93)", "rgb(124, 82, 255)"],
    CyPU: ["#0099C6", "#990099"],
    PkYg: ["#DD4477", "#66AA00"],
    DrDb: ["#B82E2E", "#316395"],
    LpLb: ["#994499", "#22AA99"],
    YlDp: ["#AAAA11", "#6633CC"],
    OrId: ["#E67300", "#3E0099"]
  },
  gray: "#777"
};

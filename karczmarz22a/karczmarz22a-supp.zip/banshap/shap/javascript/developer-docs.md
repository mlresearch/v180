## Starting the dev server (for local development)

<pre>
npm run dev
</pre>

## Building the package

<pre>
npm run build
</pre>

## Publishing the package to npm 

A new shapjs version can be published to [npm](https://www.npmjs.com/package/shapjs):

<pre>
npm run pub
</pre>
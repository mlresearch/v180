import randExp from './random-explanation';

document.querySelector('#visualizer').draw(randExp());
document.querySelector('#visualizer2').draw(randExp());

import matplotlib
matplotlib.use('Agg')
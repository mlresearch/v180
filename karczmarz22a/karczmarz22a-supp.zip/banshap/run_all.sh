#!/bin/bash
conda activate feature_importance
cd ipython
export "PYTHONPATH=$PYTHONPATH:$(pwd)"
echo $PYTHONPATH
echo $pwd
python lib/run_all.py

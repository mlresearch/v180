function trans_Y = transform_y(Y)
n = size(Y,1);
K = 10;
trans_Y = zeros(n,K);
Y(Y==0)= 10;
for i = 1:n
    trans_Y(i,Y(i)) = 1; 
end
end

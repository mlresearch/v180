%MNIST
X = loadMNISTImages("train-images-idx3-ubyte");
Y = loadMNISTLabels("train-labels-idx1-ubyte");
test_X = loadMNISTImages("t10k-images-idx3-ubyte");
test_Y = loadMNISTLabels("t10k-labels-idx1-ubyte");
N = size(X, 1);
index = randperm(N, N);
X = X(index, :);
Y = Y(index);

Y = Y + 1;
test_Y = test_Y + 1;
K = 10;
p = 784;


train{1,1} = X;
train{1,2} = Y;
test{1,1} = test_X;
test{1,2} = test_Y;

data = data_with_Byzantine(train, test, 50, 5);
[error_1, error_2] = model_run(data, 20);

data = data_with_Byzantine(train, test, 50, 0);
[error_3, error_4] = model_run(data, 20);
sys_1 = [error_3 error_4];
x = 0:20;
plot(x, sys_1);

T = 20;
for i = 1:10
    index = randperm(N, N);
    X = X(index, :);
    Y = Y(index);
    train{1,1} = X;
    train{1,2} = Y;
    data = data_with_Byzantine(train, test, 20, 2);
    [error_iter(:, i), error_iter_1(:, i)] = model_run(data, T);
end
mean_error = mean(error_iter, 2);
median_error = mean(error_iter_1, 2);

for i = 1:10
    index = randperm(N, N);
    X = X(index, :);
    Y = Y(index);
    train{1,1} = X;
    train{1,2} = Y;
    data = data_with_Byzantine(train, test, 20, 0);
    [error_iter(:, i), error_iter_1(:, i)] = model_run(data, T);
end


load('data_batch_1.mat')
X = im2double(data);
Y = labels + 1;
N = size(X, 1);
index = randperm(N, N);
X = X(index, :);
Y = Y(index);

load('test_batch.mat')
test_X = im2double(data);
test_Y = labels + 1;


train{1,1} = X;
train{1,2} = Y;
test{1,1} = test_X;
test{1,2} = test_Y;
data = data_with_Byzantine(train, test, 10, 0);
[error_1, error_2] = model_run(data, 20);
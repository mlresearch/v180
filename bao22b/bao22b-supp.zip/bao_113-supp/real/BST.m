function theta = BST(theta_0, thres)
    if(1 - thres/norm(theta_0, 2) > 0)
        theta = (1 - thres/norm(theta_0, 2)) * theta_0;
    end
    if(1 - thres/norm(theta_0, 2) <= 0);
        theta = theta_0 - theta_0;
end
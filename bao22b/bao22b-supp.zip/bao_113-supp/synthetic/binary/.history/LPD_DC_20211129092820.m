function [beta_debias, clime_lambda] = LPD_CV(train_data, valid_data)
    train_X = train_data{1, 1};
    train_Y = train_data{1, 2};

    valid_X = valid_data{1, 1};
    valid_Y = valid_data{1, 2};
    p = size(valid_X, 2);

    cov_class = zeros(p, p);
    for k = 1:2
        ind_k = find(train_Y == k);
        X_class = train_X(ind_k,:);
        mu_est(:,k) = mean(X_class, 1)';
        cov_class = cov_class + size(X_class,1) * cov(X_class);
    end
    Sigma = cov_class/size(train_X, 1);
    delta = mu_est(:, 2) - mu_est(:, 1);
    mu_hat = (mu_est(:, 1) + mu_est(:, 2))/2;

    x0 = zeros(p, 1);
    values = linspace(0.1, 0.2, 10);

    %% solve LPD
    error_cv = zeros(length(values), 1);
    for i = 1:length(values)
        lambda = values(i);
        xp = clime(x0, Sigma,  delta, lambda);
        beta_set(:, i) = xp;
        pred_value = (valid_X - mu_hat') * xp;
        pred_Y = pred_value ;
        pred_Y(find(pred_value <= 0)) = 1;
        pred_Y(find(pred_value > 0)) = 2;
        error_cv(i) = 1 - mean(pred_Y == valid_Y);
    end

    min_error_ind = find(error_cv == min(error_cv));
    beta_hat = beta_set(:, min_error_ind(1));

    %% solve CLIME
    new_values = linspace(0.45, 0.95, 10);
    likelihood = zeros(length(new_values), 1);
    for i = 1:length(new_values)
        lambda = new_values(i);
        Omega_tmp = zeros(p, p);
        for j = 1:p
            e_j = zeros(p, 1);
            e_j(j) = 1;
            Omega_tmp(j, :) = clime(x0, Sigma, e_j, lambda);
        end
        %likelihood(i) = trace(Sigma * Omega_tmp) - log(det(Omega_tmp));
        Omega_list{i} = Omega_tmp;
        beta_debias_tmp = beta_hat - Omega_tmp * (Sigma * beta_hat - delta);

        ht_values = linspace(0.01, 0.1, 10);
        ht_error_cv = zeros(length(ht_values), 1);
        for l = 1:length(ht_values)
            ht_theta = beta_debias_tmp;
            ht_theta(find(abs(beta_debias_tmp) < ht_values(i))) = 0;
            pred_value = (valid_X - mu_hat') * ht_theta;
            pred_Y = pred_value ;
            pred_Y(find(pred_value <= 0)) = 1;
            pred_Y(find(pred_value > 0)) = 2;
            ht_error_cv(l) = 1 - mean(pred_Y == valid_Y);
        end
        l_error_cv(i) = min(ht_error_cv)
    end

    l_ind = find(l_error_cv == min(l_error_cv));
    Omega_hat = Omega_list{l_ind(1)};
    clime_lambda = new_values(l_ind(1));
    
    beta_debias = beta_hat - Omega_hat * (Sigma * beta_hat - delta);












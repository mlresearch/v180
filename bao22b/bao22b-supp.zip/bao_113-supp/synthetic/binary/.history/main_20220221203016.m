% theta ture
p = 200; K = 2;
sigma = zeros(p,p);
for i = 1:p
    for k = 1:p
        sigma(i,k) = 0.8^(abs(i-k));
    end
end
mu = zeros(p, 2);
mu(:, 2) = [ones(10, 1); zeros(p - 10, 1)];
theta_true = inv(sigma) * (mu(:,2) - mu(:,1));
theta_true(find(abs(theta_true) < 1e-3)) = 0;


N = 10000;
p = 500;
[avg_mat_1, std_mat_1] = binary_run(N, 20, p, theta_true); % obtain the results in Table 2 (p = 500)


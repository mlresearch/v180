function avg = avg_ell2(theta_hat, theta_true)
    K = size(theta_hat, 2);
    for i = 1:K
        ell_2(i) = norm(theta_hat(:,i) - theta_true(:,i), 2);
    end
    avg = sum(ell_2)/(K+1);
end
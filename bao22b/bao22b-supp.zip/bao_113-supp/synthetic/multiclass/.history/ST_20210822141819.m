function theta = ST(theta, thres)
    p = length(theta);
    theta_st = theta;
    for j = 1:p
        if(abs(theta(j)) > thres)
            theta_st(j) = (1 - thres/abs(theta(j))) * theta(j);
        end
        if(abs(theta(j)) <= thres)
            theta_st(j) = 0;
        end
    end
end
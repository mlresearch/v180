function theta =  lasso_ISTA(H, g, lambda, eta)
    p = size(H, 1);
    theta_old = zeros(p, 1);
    theta_new = zeros(p, 1);
    while theta_diff > 1e-4
        theta_update = theta_old - eta*(H*theta_old - g)
        
    end
function pred_value = bayes_value(X, theta, mu_hat, pi_hat, K)
    n = size(X, 1);
    p = size(X, 2);
    for i = 1:n
        pred_value(i, :) = (X(i, :) - (mu_hat + mu_hat(:, 1))/2)
    end
    
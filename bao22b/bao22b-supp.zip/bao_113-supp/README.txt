This repository contains Matlab code for the UAI submission "Byzantine-Tolerant Distributed Multiclass Sparse Linear Discriminant Analysis".

- 'synthetic' folder contains codes for our experiments on synthetic data (multi-class and binary-class task). 

- 'real' folder contains codes for experiments on two real datasets.

- There is a script named 'demo.R' in each subfolder, which shows how to reproduce the results in each experiment.
#include <bits/stdc++.h>
using namespace std;

const int maxn=200+5;
const int maxr=10+3;
const double pp[5]={0.02,0.03,0.04,0.05,0.06}; //probability of partitioning between neighbors
int n,m;
double p;
int sum[maxn],num[maxn][maxn];
int per[maxn];
int pos[maxn][maxn][maxn];
double Rand()
{
	double kk=rand()%10000;
	return kk/10000.0;
}
int init()  //create one data
{
	printf("%d %d %.2lf\n",n,m,p);
	memset(num,0,sizeof(num));
	for (int ag=1;ag<=n;ag++)
	{
		for (int i=1;i<=m;i++) per[i]=i;
		random_shuffle(per+1,per+m+1);
		sum[ag]=1;
		int las=1;
		for (int i=1;i<m;i++)
		{
			if (Rand()<p) //partition criteria
			{
				num[ag][sum[ag]]=i-las+1;
				for (int j=las;j<=i;j++) 
				  pos[ag][sum[ag]][j-las+1]=per[j];
				sum[ag]++;
				las=i+1;
			}
		}
		num[ag][sum[ag]]=m-las+1;
		for (int j=las;j<=m;j++) 
			pos[ag][sum[ag]][j-las+1]=per[j];
	}
	for (int i=1;i<=n;i++)
	{
		printf("%d ",sum[i]);
		for (int j=1;j<=sum[i];j++)
		{
			printf("(");
			for (int k=1;k<num[i][j];k++)
			 printf("%d ",pos[i][j][k]);
			printf("%d)",pos[i][j][num[i][j]]);
		}
		printf("\n");
	}
	return 0;
}
int main()
{
	srand(unsigned(time(0)));
	const string st1="dataset";
	const string st3=".in";
	int pn=0;
	string temp=st1+to_string(pn)+st3;
	freopen(temp.c_str(),"w",stdout);
	int totnum=0;
	for (n=2;n<=20;n++)  //different choices of the number of agents
	 for (m=n;m<=5*n;m++) //different choices of the number of items 
	  for (int k=0;k<5;k++) //different partitioning probability
	   for (int ts=0;ts<30;ts++) //each setting has 30 different instances
	   {
	   	p=pp[k]; //collect the partitioning probability
	   	totnum++;
	   	printf("%d:\n",totnum);
	   	init();
	   	if (totnum%5000==0)
	  	{
	  		pn++;
			temp=st1+to_string(pn)+st3;
			freopen(temp.c_str(),"w",stdout);
		}
	   }
	return 0;
}

Part 1. Files Description.
1.makedata.cpp:
   This is to generate the data for the experiment.
   The detailed comments and parameters can be seen in the code.
2.runprogram.cpp:
  This is to calculate the performance and running time for four different algorithms for all datasets.
  The detailed comments of the program can be seen in the code.
  1,2,3,4 correspond to Baseline, LocalSearch, Matching, Greedy respectively in order.
3.printresult.cpp:
  This is to summary the results for all datasets for easily checking the results.

Part 2. User's Guidance.
1. Run the program makedata.cpp, then this will generate all input data into the file dataset*.in. Each dataset.in covers not more than 5000 instances.
    You can adjust the parameters according to your need. 
    When adjusting the parameters, you should adjust the number of data files in runprogram.cpp and printresult.cpp correspondingly.
2. Run the program runprogram.cpp, then this will generate all output for all dataset*.in to corresponding rawresult*.out.
    Here, in the output, 1,2,3,4 correspond to Baseline, LocalSearch, Matching, Greedy respectively in order.
3. Run the program printresult.cpp, then this will summary all rawresult*.out and print the average perfermance and running time for each n in the screen.
    Here, 1,2,3,4 still correspond to Baseline, LocalSearch, Matching, Greedy respectively in order.

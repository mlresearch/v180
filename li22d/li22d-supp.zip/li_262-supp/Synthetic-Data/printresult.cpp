#include <bits/stdc++.h>
using namespace std;

const double eps=1e-6;
const int maxn=200+5;
const int maxr=10+3;
char tempst[maxn];
double totp[maxn][5];
double avgp[5],avgt[5]; 
double tott[maxn][5];
int totn[maxn];
int avgn;
int n,m;
double p;
int sum[maxn],num[maxn][maxn];
int pd[maxn][maxn];
int init() //data input
{
	memset(num,0,sizeof(num));
	scanf("%d%d%lf\n",&n,&m,&p);
	for (int i=1;i<=n;i++)
	{
		scanf("%d ",&sum[i]);
		char ch=getchar();
		int now=0;
		int obs=0;
		while (ch!='\n')
		{
			now++;
			num[i][now]=0;
			while (ch!=')')
			{
				ch=getchar();
				int s=0;
				for (s=ch-'0',ch=getchar();isdigit(ch);s=s*10+ch-'0',ch=getchar());
				obs++;
				num[i][now]++;
				pd[i][s]=now;
			}
			ch=getchar();
		}
	}
	return 0;
}

int main() //summary results for each n 
{
	string st1="rawresult";
	string st3=".out";
	//freopen("summaryresult.out","w",stdout);
	for (int i=0;i<=25;i++) //the number of data files
	{
		string temp=st1+to_string(i)+st3;
		freopen(temp.c_str(),"r",stdin);
		int num;
		while (scanf("%d:\n",&num)!=EOF)
		{
			init();
			double ans1,ans2,ans3,ans4;
			scanf("1:%lf 2:%lf 3:%lf 4:%lf\n",&ans1,&ans2,&ans3,&ans4);
			int t1,t2,t3,t4;
			scanf("time: 1:%d 2:%d 3:%d 4:%d\n",&t1,&t2,&t3,&t4);
			cin.getline(tempst,maxn);
			cin.getline(tempst,maxn);
			totn[n]++;
			totp[n][1]+=ans1,totp[n][2]+=ans2,totp[n][3]+=ans3,totp[n][4]+=ans4;
			tott[n][1]+=t1,tott[n][2]+=t2,tott[n][3]+=t3,tott[n][4]+=t4;
			avgn++;
			avgp[1]+=ans1,avgp[2]+=ans2,avgp[3]+=ans3,avgp[4]+=ans4;
			avgt[1]+=t1,avgt[2]+=t2,avgt[3]+=t3,avgt[4]+=t4;
		}
	}
	for (int i=2;i<=20;i++)
	 printf("n=%d: %d\n Performance: 1:%.3lf 2:%.3lf 3:%.3lf 4:%.3lf\n Running time: 1:%.2lf 2:%.2lf 3:%.2lf 4:%.2lf\n\n",
	 		i,totn[i],totp[i][1]/totn[i],totp[i][2]/totn[i],totp[i][3]/totn[i],totp[i][4]/totn[i],
			tott[i][1]/totn[i],tott[i][2]/totn[i],tott[i][3]/totn[i],tott[i][4]/totn[i]);
	printf("Avg: %d\n Performance: 1:%.4lf 2:%.4lf 3:%.4lf 4:%.4lf\n Running time: 1:%.2lf 2:%.2lf 3:%.2lf 4:%.2lf\n\n",
		avgn,avgp[1]/avgn,avgp[2]/avgn,avgp[3]/avgn,avgp[4]/avgn,
		avgt[1]/avgn,avgt[2]/avgn,avgt[3]/avgn,avgt[4]/avgn);
	for (int i=1;i<=4;i++)
	{
		for (int j=2;j<=20;j++)
		{
			printf("(%d,%.3lf) ",j,tott[j][i]/totn[j]);
		}
		printf("\n");
	}
	return 0;
}

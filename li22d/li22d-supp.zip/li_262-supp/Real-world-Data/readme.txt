Part 1. File Description.
1. from data1.in to data11.in:
    Each file corresponds to one dataset from Preflib.
2. from result1.out to result11.out:
    Each file corresponds to the result for the corresponding dataset output by runprogram.cpp.
    1,2,3,4 correspond to Baseline, LocalSearch, Matching, Greedy respectively in order.
3.runprogram.cpp:
   This is to calculate the performance and running time for four different algorithms for all datasets.
   The detailed comments of the program can be seen in the runprogram.cpp in Simulation-Data folder.
4.printresult.cpp:
   This is to summary the results for all datasets for easily checking the results.

Part 2. User's Guidance.
1. Run the program runprogram.cpp, the program will output from result1.out to result11.out for all data*.in.
2. Run the program printresult.cpp, the program will summary all result*.out and output the performance and time of all 4 algorithms for all data in the increasing order of number of agents in the screen.
Here, still 1,2,3,4 correspond to Baseline, LocalSearch, Matching, Greedy respectively in order.

#include <bits/stdc++.h>
using namespace std;

const double eps=1e-6;
const int maxn=200+5;
const int maxr=10+3;
char tempst[maxn];
double totp[maxn][5];
double tott[maxn][5];
int totn[maxn];
int n,m;
double p;
int sum[maxn],num[maxn][maxn];
int pd[maxn][maxn];
int init()
{
	memset(num,0,sizeof(num));
	scanf("%d%d%lf\n",&n,&m,&p);
	for (int i=1;i<=n;i++)
	{
		scanf("%d ",&sum[i]);
		char ch=getchar();
		int now=0;
		int obs=0;
		while (ch!='\n')
		{
			now++;
			num[i][now]=0;
			while (ch!=')')
			{
				ch=getchar();
				int s=0;
				for (s=ch-'0',ch=getchar();isdigit(ch);s=s*10+ch-'0',ch=getchar());
				obs++;
				num[i][now]++;
				pd[i][s]=now;
			}
			ch=getchar();
		}
	}
	return 0;
}
struct Term
{
	int n,m;
	double ans1,ans2,ans3,ans4;
	int t1,t2,t3,t4;
	int ins1(double s1,double s2,double s3,double s4)
	{
		ans1=s1;ans2=s2;ans3=s3;ans4=s4;
		return 0;
	}
	int ins2(int tt1,int tt2,int tt3,int tt4)
	{
		t1=tt1;t2=tt2;t3=tt3;t4=tt4;
		return 0;
	}
	int print()
	{
		printf("n=%d m=%d:\nPerformance: 1:%.3lf 2:%.3lf 3:%.3lf 4:%.3lf\n Running time: 1:%d 2:%d 3:%d 4:%d\n\n",
		n,m,ans1,ans2,ans3,ans4,t1,t2,t3,t4);
		return 0;
	}
}tes[22];
bool cmp(Term a,Term b)
{
	if (a.n==b.n) return a.m<b.m;
	return a.n<b.n;
}
int main() // summary the results 
{
	string st1="result";
	string st3=".out";
	//freopen("summaryresult.out","w",stdout);
	for (int i=1;i<=11;i++) 
	{
		string temp=st1+to_string(i)+st3;
		freopen(temp.c_str(),"r",stdin);
		int num;
		init();
		double ans1,ans2,ans3,ans4;
		scanf("1:%lf 2:%lf 3:%lf 4:%lf\n",&ans1,&ans2,&ans3,&ans4);
		int t1,t2,t3,t4;
		scanf("time: 1:%d 2:%d 3:%d 4:%d\n",&t1,&t2,&t3,&t4);
		cin.getline(tempst,maxn);
		cin.getline(tempst,maxn);
		tes[i].n=n;tes[i].m=m;
		tes[i].ins1(ans1,ans2,ans3,ans4);
		tes[i].ins2(t1,t2,t3,t4);
	}
	sort(tes+1,tes+11+1,cmp);
	for (int i=1;i<=11;i++) tes[i].print();
	return 0;
}

import matplotlib.pyplot as plt
import matplotlib
import time
import scipy.io
import numpy as np


x=[0.1,0.5,1,5,10]

values=[0.1,0.5,1,5,10]

y_mnist_delta4_dpsgda_nonlinear_w=[0.00038597, 0.0001313, 0.00010829, 0.00006617, 0.00005629]
y_mnist_delta5_dpsgda_nonlinear_w=[0.00046774, 0.00016068, 0.00011934, 0.00007215, 0.00006149]
y_mnist_delta6_dpsgda_nonlinear_w=[0.00054054, 0.00017836, 0.00012974, 0.00007371, 0.00006214]
y_mnist_delta4_dpsgda_nonlinear_c=[0.0000863979, 0.000029391, 0.0000242403, 0.0000148119, 0.0000126003]
y_mnist_delta5_dpsgda_nonlinear_c=[0.0001047018, 0.0000359676, 0.0000267138, 0.0000161505, 0.0000137643]
y_mnist_delta6_dpsgda_nonlinear_c=[0.0001209978, 0.0000399252, 0.0000290418, 0.0000164997, 0.0000139098]

y_ijcnn1_delta4_dpsgda_nonlinear_w=[0.00147682, 0.00048093, 0.0003567, 0.00021771, 0.00018491]
y_ijcnn1_delta5_dpsgda_nonlinear_w=[0.00179539, 0.00054489, 0.00039565, 0.00023616, 0.00020049]
y_ijcnn1_delta6_dpsgda_nonlinear_w=[0.00207788, 0.00060311, 0.00043501, 0.0002419, 0.00020295]
y_ijcnn1_delta4_dpsgda_nonlinear_c=[0.0012761886, 0.0004155939, 0.000308241, 0.0001881333, 0.0001597893]
y_ijcnn1_delta5_dpsgda_nonlinear_c=[0.0015514797, 0.0004708647, 0.0003418995, 0.0002040768, 0.0001732527]
y_ijcnn1_delta6_dpsgda_nonlinear_c=[0.0017955924, 0.0005211753, 0.0003759123, 0.000209037, 0.0001753785]


y_fmnist_delta4_dpsgda_nonlinear_w=[0.00071256, 0.0002424, 0.00019992, 0.00012216, 0.00010392]
y_fmnist_delta5_dpsgda_nonlinear_w=[0.00086352, 0.00029664, 0.00022032, 0.0001332, 0.00011352]
y_fmnist_delta6_dpsgda_nonlinear_w=[0.00099792, 0.00032928, 0.00023952, 0.00013608, 0.00011472]
y_fmnist_delta4_dpsgda_nonlinear_c=[0.0001312298, 0.000044642, 0.0000368186, 0.0000224978, 0.0000191386]
y_fmnist_delta5_dpsgda_nonlinear_c=[0.0001590316, 0.0000546312, 0.0000405756, 0.000024531, 0.0000209066]
y_fmnist_delta6_dpsgda_nonlinear_c=[0.0001837836, 0.0000606424, 0.0000441116, 0.0000250614, 0.0000211276]


y_mnist_delta4_dpsgda_linear_w=[0.00133052, 0.00042402, 0.0003145, 0.00019388, 0.00016687]
y_mnist_delta5_dpsgda_linear_w=[0.00161727, 0.00048137, 0.00035224, 0.00020868, 0.00017834]
y_mnist_delta6_dpsgda_linear_w=[0.00187183, 0.00053539, 0.00038184, 0.00021423, 0.00018056]
y_mnist_delta4_dpsgda_linear_c=[0.0001319732, 0.0000420582, 0.000031195, 0.0000192308, 0.0000165517]
y_mnist_delta5_dpsgda_linear_c=[0.0001604157, 0.0000477467, 0.0000349384, 0.0000206988, 0.0000176894]
y_mnist_delta6_dpsgda_linear_c=[0.0001856653, 0.0000531049, 0.0000378744, 0.0000212493, 0.0000179096]

y_ijcnn1_delta4_dpsgda_linear_w=[0.00048136, 0.00013882, 0.00010032, 0.00006039, 0.0000517]
y_ijcnn1_delta5_dpsgda_linear_w=[0.00058641, 0.0001573, 0.00011033, 0.00006446, 0.00005489]
y_ijcnn1_delta6_dpsgda_linear_w=[0.00067936, 0.00017446, 0.00012111, 0.00006655, 0.00005566]
y_ijcnn1_delta4_dpsgda_linear_c=[0.0002831272, 0.0000816514, 0.0000590064, 0.0000355203, 0.000030409]
y_ijcnn1_delta5_dpsgda_linear_c=[0.0003449157, 0.000092521, 0.0000648941, 0.0000379142, 0.0000322853]
y_ijcnn1_delta6_dpsgda_linear_c=[0.0003995872, 0.0001026142, 0.0000712347, 0.0000391435, 0.0000327382]


y_fmnist_delta4_dpsgda_linear_w=[0.00222952, 0.00071052, 0.000527, 0.00032488, 0.00027962]
y_fmnist_delta5_dpsgda_linear_w=[0.00271002, 0.00080662, 0.00059024, 0.00034968, 0.00029884]
y_fmnist_delta6_dpsgda_linear_w=[0.00313658, 0.00089714, 0.00063984, 0.00035898, 0.00030256]
y_fmnist_delta4_dpsgda_linear_c=[0.000178002, 0.000056727, 0.000042075, 0.000025938, 0.0000223245]
y_fmnist_delta5_dpsgda_linear_c=[0.0002163645, 0.0000643995, 0.000047124, 0.000027918, 0.000023859]
y_fmnist_delta6_dpsgda_linear_c=[0.0002504205, 0.0000716265, 0.000051084, 0.0000286605, 0.000024156]


y_mnist_delta4_NSEG=[0.0018012364, 0.0005740314, 0.000425765, 0.0002624716, 0.0002259059]
y_mnist_delta5_NSEG=[0.0021894339, 0.0006516709, 0.0004768568, 0.0002825076, 0.0002414338]
y_mnist_delta6_NSEG=[0.0025340531, 0.0007248023, 0.0005169288, 0.0002900211, 0.0002444392]

y_ijcnn1_delta4_NSEG=[0.0008034336, 0.0002317032, 0.0001674432, 0.0001007964, 0.000086292]
y_ijcnn1_delta5_NSEG=[0.0009787716, 0.000262548, 0.0001841508, 0.0001075896, 0.0000916164]
y_ijcnn1_delta6_NSEG=[0.0011339136, 0.0002911896, 0.0002021436, 0.000111078, 0.0000929016]

y_fmnist_delta4_NSEG=[0.0026649956, 0.0008493006, 0.000629935, 0.0003883364, 0.0003342361]
y_fmnist_delta5_NSEG=[0.0032393481, 0.0009641711, 0.0007055272, 0.0004179804, 0.0003572102]
y_fmnist_delta6_NSEG=[0.0037492249, 0.0010723717, 0.0007648152, 0.0004290969, 0.0003616568]


fig = plt.figure()
plt.plot(x,y_mnist_delta6_NSEG, color='r', linestyle='-', label = 'MNIST_NSEG',lw = 2)
plt.plot(x,y_mnist_delta6_dpsgda_linear_w, color='r', linestyle='--', label = 'MNIST_DP-SGDA_w',lw = 2)
plt.plot(x,y_mnist_delta6_dpsgda_linear_c, color='r', linestyle=':', label = 'MNIST_DP-SGDA_v',lw = 2)
plt.plot(x,y_ijcnn1_delta6_NSEG, color='b', linestyle='-', label = 'ijcnn1_NSEG',lw = 2)
plt.plot(x,y_ijcnn1_delta6_dpsgda_linear_w, color='b', linestyle='--', label = 'ijcnn1_DP-SGDA_w',lw = 2)
plt.plot(x,y_ijcnn1_delta6_dpsgda_linear_c, color='b', linestyle=':', label = 'ijcnn1_DP-SGDA_v',lw = 2)
plt.plot(x,y_fmnist_delta6_NSEG, color='g', linestyle='-', label = 'Fashion-MNIST_NSEG',lw = 2)
plt.plot(x,y_fmnist_delta6_dpsgda_linear_w, color='g', linestyle='--', label = 'Fashion-MNIST_DP-SGDA_w',lw = 2)
plt.plot(x,y_fmnist_delta6_dpsgda_linear_c, color='g', linestyle=':', label = 'Fashion-MNIST_DP-SGDA_v',lw = 2)
plt.legend(prop={'size': 8, 'weight':'bold'})
plt.yscale('log',base=10)
plt.xticks(x,values)
plt.xlabel(r'$\epsilon$', fontsize=15)
plt.ylabel(r'$\sigma$', fontsize=15)
plt.text(0.1, 0.00002, r'$\bf{(a)}$', fontsize=15)
# plt.ylim((0.00001, 0.1))
plt.show()
fig.savefig('./fig/{}.pdf'.format('noise_size_delta-6'), bbox_inches='tight', pad_inches = 0)

fig = plt.figure()
plt.plot(x,y_mnist_delta5_NSEG, color='r', linestyle='-', label = 'MNIST_NSEG',lw = 2)
plt.plot(x,y_mnist_delta5_dpsgda_linear_w, color='r', linestyle='--', label = 'MNIST_DP-SGDA_w',lw = 2)
plt.plot(x,y_mnist_delta5_dpsgda_linear_c, color='r', linestyle=':', label = 'MNIST_DP-SGDA_v',lw = 2)
plt.plot(x,y_ijcnn1_delta5_NSEG, color='b', linestyle='-', label = 'ijcnn1_NSEG',lw = 2)
plt.plot(x,y_ijcnn1_delta5_dpsgda_linear_w, color='b', linestyle='--', label = 'ijcnn1_DP-SGDA_w',lw = 2)
plt.plot(x,y_ijcnn1_delta5_dpsgda_linear_c, color='b', linestyle=':', label = 'ijcnn1_DP-SGDA_v',lw = 2)
plt.plot(x,y_fmnist_delta5_NSEG, color='g', linestyle='-', label = 'Fashion-MNIST_NSEG',lw = 2)
plt.plot(x,y_fmnist_delta5_dpsgda_linear_w, color='g', linestyle='--', label = 'Fashion-MNIST_DP-SGDA_w',lw = 2)
plt.plot(x,y_fmnist_delta5_dpsgda_linear_c, color='g', linestyle=':', label = 'Fashion-MNIST_DP-SGDA_v',lw = 2)
plt.legend(prop={'size': 8, 'weight':'bold'})
plt.yscale('log',base=10)
plt.xticks(x,values)
plt.xlabel(r'$\epsilon$', fontsize=15)
plt.ylabel(r'$\sigma$', fontsize=15)
plt.text(0.1, 0.00002, r'$\bf{(a)}$', fontsize=15)
plt.show()
fig.savefig('./fig/{}.pdf'.format('noise_size_delta-5'), bbox_inches='tight', pad_inches = 0)

fig = plt.figure()
plt.plot(x,y_mnist_delta4_NSEG, color='r', linestyle='-', label = 'MNIST_NSEG',lw = 2)
plt.plot(x,y_mnist_delta4_dpsgda_linear_w, color='r', linestyle='--', label = 'MNIST_DP-SGDA_w',lw = 2)
plt.plot(x,y_mnist_delta4_dpsgda_linear_c, color='r', linestyle=':', label = 'MNIST_DP-SGDA_v',lw = 2)
plt.plot(x,y_ijcnn1_delta4_NSEG, color='b', linestyle='-', label = 'ijcnn1_NSEG',lw = 2)
plt.plot(x,y_ijcnn1_delta4_dpsgda_linear_w, color='b', linestyle='--', label = 'ijcnn1_DP-SGDA_w',lw = 2)
plt.plot(x,y_ijcnn1_delta4_dpsgda_linear_c, color='b', linestyle=':', label = 'ijcnn1_DP-SGDA_v',lw = 2)
plt.plot(x,y_fmnist_delta4_NSEG, color='g', linestyle='-', label = 'Fashion-MNIST_NSEG',lw = 2)
plt.plot(x,y_fmnist_delta4_dpsgda_linear_w, color='g', linestyle='--', label = 'Fashion-MNIST_DP-SGDA_w',lw = 2)
plt.plot(x,y_fmnist_delta4_dpsgda_linear_c, color='g', linestyle=':', label = 'Fashion-MNIST_DP-SGDA_v',lw = 2)
plt.legend(prop={'size': 8, 'weight':'bold'})
plt.yscale('log',base=10)
plt.xticks(x,values)
plt.xlabel(r'$\epsilon$', fontsize=15)
plt.ylabel(r'$\sigma$', fontsize=15)
plt.text(0.1, 0.00002, r'$\bf{(b)}$', fontsize=15)
plt.show()
fig.savefig('./fig/{}.pdf'.format('noise_size_delta-4'), bbox_inches='tight', pad_inches = 0)

 
 

